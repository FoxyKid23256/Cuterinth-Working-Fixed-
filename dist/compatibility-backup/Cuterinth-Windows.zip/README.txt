﻿Cuterinth for Windows

1. Install Modrinth App in its default location.
2. Close Modrinth completely.
3. Extract this ZIP and open Cuterinth.exe.
4. Keep Cuterinth running in the background while Modrinth is open.

Themes download automatically at startup from:
https://github.com/FoxyKid23256/Cuterinth-Working-Fixed-/tree/main/themes

Downloaded themes are cached for offline use, and bundled themes provide a fallback.
Your imported themes and selection are saved in %APPDATA%\Cuterinth\themes.json.
The downloaded preset cache is %APPDATA%\Cuterinth\github-themes.json.
Download details are logged to %APPDATA%\Cuterinth\Cuterinth.log.

Node.js is not required. This launcher uses Windows .NET Framework 4.x.
